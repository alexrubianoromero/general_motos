<html>
<head><title>grabado</title>
	<link rel="stylesheet" href="../css/normalize.css">
	<link rel="stylesheet" href="../css/style.css"></head>
<body >


<BR>
DOCUMENTO GRABADO

</FONT>
<BR>
ESTE REGISTRO HA SIDO ADICIONADO A LA BASE DE DATOS

<BR>

POR FAVOR HAGA CLICK EN LA OPCION DESEADA

  <BR><a href=../menu_principal.php><h2>Pagina Principal<h2></a>


</BODY>
</HTML>

