<?php
include('../valotablapc.php');

$sql_grabar_salida = "insert into $tabla23 (fecha_recibo) values () ";

?>