<?php

class itemdOrdenControlador2
{
    public function __construct()
    {
        echo 'buenas llego a items';
    }
}


?>


