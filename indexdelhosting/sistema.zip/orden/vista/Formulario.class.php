<?php

Class Formulario{

    public function mensaje(){
                echo 'mensaje desde la clase ';
    }
}

?>