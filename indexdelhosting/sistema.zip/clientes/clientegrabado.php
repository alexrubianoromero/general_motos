<!DOCTYPE html>
<html lang="es"  class"no-js">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link rel="stylesheet" href="../css/normalize.css">
	<link rel="stylesheet" href="../css/style.css">
</head>
<body>

<h1>DOCUMENTO GRABADO<h1>

<h2>  LOS DATOS DEL CLIENTE HAN SIDO ADICIONADOS A LA BASE DE DATOS <h2>

  
<BR>

<h2>  POR FAVOR HAGA CLICK EN LA OPCION DESEADA

  <BR><a href=../menu_principal.php><h2>Pagina Principal<h2></a>
  <h2>
  
</BODY>
</HTML>

