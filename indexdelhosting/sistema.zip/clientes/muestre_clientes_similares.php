<?php
session_start();
include('../valotablapc.php');

				echo '<pre>';
				print_r($_POST);
				echo '</pre>';
				
?>
<!DOCTYPE html >
<html lang="es"  class"no-js">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>lCIENTES SIMILARES </title>
</head>

<body>



	
</body>
</html>
