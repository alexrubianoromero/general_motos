<!DOCTYPE html>
<html lang="es"  class"no-js">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
	<link rel="stylesheet" href="../css/normalize.css">
	<link rel="stylesheet" href="../css/style.css">
</head>

<body>
<br />
 <a href="../menu_principal.php"><h3>  Menu Principal  </h3></a>  
 
 <a href="index.php"><h3>  Menu Anterior  </h3></a>  
</body>
</html>
