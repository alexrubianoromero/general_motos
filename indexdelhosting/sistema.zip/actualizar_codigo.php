<?php
<? include("../empresa.php");
include("../valotablapc.php");

echo '<pre>';
print_r($_POST);
echo '</pre>';

?>